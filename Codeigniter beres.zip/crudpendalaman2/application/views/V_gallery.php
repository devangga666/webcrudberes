<html>
<head>
	<title>Data Gambar</title>
</head>
<body>
<h1>Data Gambar</h1><hr>
<a href="form.php">Tambah Gambar</a><br><br>
<table border="1" cellpadding="8">
<tr>
	<th>No</th>
	<th>Gambar</th>
	<th>Nama File</th>
	<th>Ukuran File</th>
	<th>Tipe File</th>

<?php
$no=1;
foreach ($gambar as $img ){
	?>
		<tr> 
		<th><?php echo $no++ ?></th>
		<th><?= "<img src='images/".['namag']."' width='70' height='90' />";?></th>
		<th><?php echo $img->namag ?></th>
		<th><?php echo $img->ukurang ?></th>
		<th><?php echo $img->tipeg ?></th>
		</tr>
</table>
<?php } ?>
</body>
</html>
