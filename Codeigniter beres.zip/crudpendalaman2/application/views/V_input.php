<!DOCTYPE html>
<head>
<title>List data Siswa</title>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
  body {
    background-image:url(https://scontent.fcgk9-2.fna.fbcdn.net/v/t31.0-8/16700597_388972374810824_1801649612069272450_o.jpg?_nc_cat=101&ccb=3&_nc_sid=6e5ad9&_nc_eui2=AeFMIr_J5Rc-rjrFjsTdUrhrbjjTbIKBwppuONNsgoHCmhXU5lwinniZl3dK6SWia9cnkjtJTZojGXBuAwEvdWY1&_nc_ohc=5-m0widiJo0AX_kcLnZ&_nc_ht=scontent.fcgk9-2.fna&oh=914c6c19f5f42d3262f3ce8ccdc6d36a&oe=60615D04);
    background-repeat:no-repeat;
    background-size:cover;
  }
</style>
</head>
</body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="<?= base_url('Control/indexadmin'); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="<?= base_url('Control/logout'); ?>">Logout</a>
      </li>
    </ul>
  </div>
</nav>
</br>
</br>
</br>
</br>
        <div class="container">
        <div class="card text-left">
        <div class="card-body">
        <form action="<?php echo base_url(). 'Control/tambah_aksi'; ?>" method="post">
        <table class="table table-bordered table-stripped">
        <tr>
        <td>Nama</td>
        <td><input type="text" name="nama" class="form-control" value="<?= $this->input->post('nama'); ?>" required></td>
        </tr>
        </tr>
			<tr>
           <td><label>kelas</label></td><td>
         <select name="kelas" class="form-control" required>
             <option value="">-- PILIH SALAH SATU --</option>
             <option value="X" <?= !empty($this->input->post('kelas') AND $this->input->post('kelas') == 'X' ? 'selected' : '' );?> >X</option>
             <option value="XI" <?= !empty($this->input->post('kelas') AND $this->input->post('kelas') == 'XI' ? 'selected' : '' );?>>XI</option>
             <option value="XII" <?= !empty($this->input->post('kelas') AND $this->input->post('kelas') == 'XII' ? 'selected' : '' );?>>XII</option>
        </select>
    
  </div>
</td>
			</tr>
            </tr>
			<tr>
           <td><label>Jurusan</label></td><td>
         <select name="jurusan" class="form-control" required>
             <option value="">-- PILIH SALAH SATU --</option>
             <option value="RPL" <?= !empty($this->input->post('jurusan') AND $this->input->post('jurusan') == 'RPL' ? 'selected' : '' );?> >RPL</option>
             <option value="TKJ" <?= !empty($this->input->post('jurusan') AND $this->input->post('jurusan') == 'TKJ' ? 'selected' : '' );?>>TKJ</option>
             <option value="Perkes" <?= !empty($this->input->post('jurusan') AND $this->input->post('jurusan') == 'Perkes' ? 'selected' : '' );?>>Perkes</option>
             <option value="Ankim" <?= !empty($this->input->post('jurusan') AND $this->input->post('jurusan') == 'Ankim' ? 'selected' : '' );?>>Ankim</option>
             <option value="Farmasi" <?= !empty($this->input->post('jurusan') AND $this->input->post('jurusan') == 'Farmasi' ? 'selected' : '' );?>>Farmasi</option>

        </select>
    
  </div>
</td>
</tr>
<tr>
<td><label>NIK</label></td>
        <td>
        <input type="text" name="nik" class="form-control" value="<?= $this->input->post('nik'); ?>" required>
        </td>
        </tr>
        <tr>
        <td><label>Alamat</label></td>
        <td>
        <input type="text" name="alamat" class="form-control" value="<?= $this->input->post('alamat'); ?>" required>
        </td>
			</tr>
            <tr>
            <td> <button type="submit" class="btn btn-primary">Kirim</button> 
            <a class="btn btn-primary" href="<?= base_url('Control/rpl'); ?>">Kembali</a>
            </tr>
        </table>
        </div>
    </body>
    </html>