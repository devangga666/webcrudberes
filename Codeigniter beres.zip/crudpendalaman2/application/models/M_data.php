<?php
class M_data extends CI_Model{
    function tentang(){
        return $this->db->get('tutor');
    }
    function tampil_data(){
        return $this->db->get('tutor');
    }
    function awal(){
        return $this->db->get('tutor');
    }
    function profiladmin(){
        return $this->db->get('user');
    }
    //Model Untuk RPL
    function tampil(){
        return $this->db->get('tutor');
    }
    function input_data($data,$table){
        $this->db->insert($table,$data);
    }
    function hapus_data($where,$table){
        $this->db->where($where);
        $this->db->delete($table);
    }
    function edit_data($where,$table){
        return $this->db->get_where($table,$where);
    }
    function update_data($where,$table,$data){
        $this->db->where($where);
        $this->db->update($table,$data);
        redirect ('Control/rpl');
    }
    //Model Untuk TKJ
    function tkj_tampil(){
        return $this->db->get('tkj');
    }
    function input_tkj($data1,$table){
        $this->db->insert($table,$data1);
    }
    function hapus_tkj($where,$table){
        $this->db->where($where);
        $this->db->delete($table);
    }
    function ganti_data($where,$table){
        return $this->db->get_where($table,$where);
    }
    function ubah_data($where,$table,$data1){
        $this->db->where($where);
        $this->db->update($table,$data1);
        redirect ('Control/tampil_tkj');
    }
    //Model Untuk Farmasi
    function farmasi_tampil(){
        return $this->db->get('farmasi');
    }
    function input_farmasi($data2,$table){
        $this->db->insert($table,$data2);
    }
    function hapus_farmasi($where,$table){
        $this->db->where($where);
        $this->db->delete($table);
    }
    function farmasi_edit($where,$table){
        return $this->db->get_where($table,$where);
    }
    function update_farmasi($where,$table,$data2){
        $this->db->where($where);
        $this->db->update($table,$data2);
        redirect('Control/farmasi');
    }
    //Model Untuk Perkes
    function perkes_tampil(){
        return $this->db->get('perkes');
    }
    function input_perkes($data3,$table){
        $this->db->insert($table,$data3);
    }
    function hapus_perkes($where,$table){
        $this->db->where($where);
        $this->db->delete($table);
    }
    function perkes_edit($where,$table){
        return $this->db->get_where($table,$where);
    }
    function update_perkes($where,$table,$data3){
        $this->db->where($where);
        $this->db->update($table,$data3);
        redirect('Control/perkes');
    }
    //Model Untuk Ankim
    function ankim_tampil(){
        return $this->db->get('ankim');
    }
    function input_ankim($data4,$table){
        $this->db->insert($table,$data4);
    }
    function hapus_ankim($where,$table){
        $this->db->where($where);
        $this->db->delete($table);
    }
    function ankim_edit($where,$table){
        return $this->db->get_where($table,$where);
    }
    function ankim_update($where,$table,$data4){
        $this->db->where($where);
        $this->db->update($table,$data4);
        redirect('Control/ankim');
    }
    //untuk index
    function userrpl(){
        return $this->db->get('tutor');
    }
    function usertkj(){
        return $this->db->get('tkj');
    }
    function userperkes(){
        return $this->db->get('perkes');
    }
    function userankim(){
        return $this->db->get('ankim');
    }
    function userfarmasi(){
        return $this->db->get('farmasi');
    }
    //untuk login
    public function get($username){
        $this->db->where('username', $username); 
        $result = $this->db->get('user')->row();

        return $result;
    }
    //gallery
    public function tampil_gambar(){
        return $this->db->get('gambar');
    }
    public function gambaran(){
        return $this->db->get("images/");
    }

}