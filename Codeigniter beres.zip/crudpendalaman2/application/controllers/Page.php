<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends MY_Controller {

	public function Admin(){
		$this->load->view('Home');
	}

	public function tentangadmin(){
		$this->load->view('Thanks');
	}
}
