<?php
    class Control extends CI_Controller{
        function __construct()
        {
            parent::__construct();
            $this->load->model('M_data');            
        }
        function indexadmin(){
            $data['tutor'] = $this->M_data->tampil_data()->result();
            $this->load->view('Home');
            $this->load->helper('url');
        }
        function tentang(){
            $data['tutor'] = $this->M_data->tentang()->result();
            $this->load->view('Tentang');
            $this->load->helper('url');
        }   
        function index(){
            $data['tutor'] = $this->M_data->awal()->result();
            $this->load->view('awal');
            $this->load->helper('url');
        }
                    //Control Untuk RPL
            function rpl(){
                $data['tutor'] = $this->M_data->tampil()->result();
                $this->load->view('V_tampil',$data);
                $this->load->helper('url');
            }
            function tambah(){
                $this->load->view('V_input');
            }
            function tambah_aksi(){
                $nama = $this->input->post('nama');
                $kelas = $this->input->post('kelas');
                $jurusan = $this->input->post('jurusan');
                $nik = $this->input->post('nik');
                $alamat = $this->input->post('alamat');

                $data = array (
                    'nama' => $nama,
                    'kelas' => $kelas,
                    'jurusan' => $jurusan,
                    'nik' => $nik,
                    'alamat' => $alamat
                );
                $this->M_data->input_data($data,'tutor');
                $this->session->set_flashdata('respon', 'added');
                redirect('Control/rpl');
            }

            function hapus($id){
                $where = array (
                    'id' => $id
                );
                $this->session->set_flashdata('respon', 'deleted');
                $this->M_data->hapus_data($where,'tutor');
                redirect('Control/rpl');
            }
            function edit($id){
                $where = array('id' => $id);
                $data['tutor'] = $this->M_data->edit_data($where,'tutor')->result();
                $this->load->view('V_edit',$data);
            }
            function update(){
                $id = $this->input->post('id');
                $nama = $this->input->post('nama');
                $kelas = $this->input->post('kelas');
                $jurusan = $this->input->post('jurusan');
                $nik = $this->input->post('nik');
                $alamat = $this->input->post('alamat');
    
                $where = array(
                    'id' => $id
                );
                $data = array(
                    'nama' => $nama,
                    'kelas' => $kelas,
                    'jurusan' => $jurusan,
                    'nik' => $nik,
                    'alamat' => $alamat
                );
                $this->session->set_flashdata('respon', 'updated');
                $this->M_data->update_data($where,'tutor',$data);
                
                redirect ('Control/rpl');
            }

                        //Control untuk Perkes


            function perkes(){
                $data3['perkes'] = $this->M_data->perkes_tampil()->result();
                $this->load->view('V_perkes',$data3);
                $this->load->helper('url');
            }
            function edit_perkes($idperkes){
                $where = array('idperkes' => $idperkes);
                $data3['perkes'] = $this->M_data->perkes_edit($where,'perkes')->result();
                $this->load->view('E_perkes',$data3);
            }
            function update_p(){
                $idperkes = $this->input->post('idperkes');
                $namaa = $this->input->post('namaa');
                $kelass = $this->input->post('kelass');
                $jurusann = $this->input->post('jurusann');
                $nikk = $this->input->post('nikk');
                $alamatt = $this->input->post('alamatt');

                $where = array (
                    'idperkes' => $idperkes
                );
                $data3 = array(
                    'namaa' => $namaa,
                    'kelass' => $kelass,
                    'jurusann' => $jurusann,
                    'nikk' => $nikk,
                    'alamatt' => $alamatt
                );
                $this->session->set_flashdata('respon', 'updated');
                $this->M_data->update_perkes($where,'perkes',$data3);
                redirect('Control/perkes');
            }
            function tambah_perkes(){
                $this->load->view('I_perkes');
            }
            function aksi_perkes(){
                $namaa = $this->input->post('namaa');
                $kelass = $this->input->post('kelass');
                $jurusann = $this->input->post('jurusann');
                $nikk = $this->input->post('nikk');
                $alamatt = $this->input->post('alamatt');

                $data3 = array (
                    'namaa' => $namaa,
                    'kelass' => $kelass,
                    'jurusann' => $jurusann,
                    'nikk' => $nikk,
                    'alamatt' => $alamatt
                );
                $this->session->set_flashdata('respon', 'added');
                $this->M_data->input_perkes($data3,'perkes');
                redirect('Control/perkes');
            }
            function hapus_p($idperkes){
                $where = array(
                    'idperkes' => $idperkes
                );
                $this->session->set_flashdata('respon', 'deleted');
                $this->M_data->hapus_perkes($where,'perkes');
                redirect('Control/perkes');
            }
                    //Control Untuk TKJ

            function tampil_tkj(){
                $data1['tkj'] = $this->M_data->tkj_tampil()->result();
                $this->load->view('V_tkj',$data1);
                $this->load->helper('url');
            }
            function ganti($idid){
                $where = array('idid' => $idid);
                $data1['tkj'] = $this->M_data->ganti_data($where,'tkj')->result();
                $this->load->view('Edit_tkj',$data1);
            }
            function ubah(){
                $idid = $this->input->post('idid');
                $idnama = $this->input->post('idnama');
                $idkelas = $this->input->post('idkelas');
                $idjurusan = $this->input->post('idjurusan');
                $idnik = $this->input->post('idnik');
                $idalamat = $this->input->post('idalamat');

                $where = array (
                    'idid' => $idid
                );
                $data1 = array(
                    'idnama' => $idnama,
                    'idkelas' => $idkelas,
                    'idjurusan' => $idjurusan,
                    'idnik' => $idnik,
                    'idalamat' => $idalamat
                );
                $this->session->set_flashdata('respon', 'updated');
                $this->M_data->ubah_data($where,'tkj',$data1);
                redirect ('Control/tampil_tkj');
            }
            function hapuss($idid){
                $where = array (
                    'idid' => $idid
                );
                $this->session->set_flashdata('respon', 'deleted');
                $this->M_data->hapus_tkj($where,'tkj');
                redirect('Control/tampil_tkj');
            }
            function tambah_tkj(){
                $this->load->view('I_tkj');
            }
            function tkj_aksi(){
                $idnama = $this->input->post('idnama');
                $idkelas = $this->input->post('idkelas');
                $idjurusan = $this->input->post('idjurusan');
                $idnik = $this->input->post('idnik');
                $idalamat = $this->input->post('idalamat');

                $data1 = array(
                    'idnama' => $idnama,
                    'idkelas' => $idkelas,
                    'idjurusan' => $idjurusan,
                    'idnik' => $idnik,
                    'idalamat' => $idalamat
                );
                $this->session->set_flashdata('respon', 'added');
                $this->M_data->input_tkj($data1,'tkj');
                redirect('Control/tampil_tkj');
            }
                    //Control Untuk Farmasi
            function farmasi(){
                $data2['farmasi'] = $this->M_data->farmasi_tampil()->result();
                $this->load->view('V_farmasi',$data2);
                $this->load->helper('url');
            }
            function tambah_farmasi(){
                $this->load->view('I_farmasi');
            }
            function aksi_farmasi(){
                $namaid = $this->input->post('namaid');
                $kelasid = $this->input->post('kelasid');
                $jurusanid = $this->input->post('jurusanid');
                $nikid = $this->input->post('nikid');
                $alamatid = $this->input->post('alamatid');

                $data2 = array (
                    'namaid' => $namaid,
                    'kelasid' => $kelasid,
                    'jurusanid' => $jurusanid,
                    'nikid' => $nikid,
                    'alamatid' => $alamatid
                );
                $this->session->set_flashdata('respon', 'added');
                $this->M_data->input_farmasi($data2,'farmasi');
                redirect('Control/farmasi');
            }
            function edit_farmasi($idd){
                $where = array('idd' => $idd);
                $data2['farmasi'] = $this->M_data->farmasi_edit($where,'farmasi')->result();
                $this->load->view('E_farmasi',$data2);
            }
            function atur(){
                $idd = $this->input->post('idd');
                $namaid = $this->input->post('namaid');
                $kelasid = $this->input->post('kelasid');
                $nikid = $this->input->post('nikid');
                $alamatid = $this->input->post('alamatid');
                

                $where = array (
                    'idd' => $idd
                );
                $data2 = array(
                    'namaid' => $namaid,
                    'kelasid' => $kelasid,
                    'jurusanid' => $jurusanid,
                    'nikid' => $nikid,
                    'alamatid' => $alamatid
                );
                $this->session->set_flashdata('respon', 'updated');
                $this->M_data->update_farmasi($where,'farmasi',$data2);
                redirect('Control/farmasi');
            }
            function hapusss($idd){
                $where = array (
                    'idd' => $idd
                );
                $this->session->set_flashdata('respon', 'deleted');
                $this->M_data->hapus_farmasi($where,'farmasi');
                redirect('Control/farmasi');
            }
            //Control Untuk Ankim
            function ankim(){
                $data4['ankim'] = $this->M_data->ankim_tampil()->result();
                $this->load->view('V_ankim',$data4);
                $this->load->helper('url');
            }
            function tambah_ankim(){
                $this->load->view('I_ankim');
            }
            function aksi_ankim(){
                $namaankim = $this->input->post('namaankim');
                $kelasankim = $this->input->post('kelasankim');
                $jurusanankim = $this->input->post('jurusanankim');
                $nikankim = $this->input->post('nikankim');
                $alamatankim = $this->input->post('alamatankim');

                $data4 = array (
                    'namaankim' => $namaankim,
                    'kelasankim' => $kelasankim,
                    'jurusanankim' => $jurusanankim,
                    'nikankim' => $nikankim,
                    'alamatankim' => $alamatankim
                );
                $this->session->set_flashdata('respon', 'added');
                $this->M_data->input_ankim($data4,'ankim');
                redirect('Control/ankim');
            }
            function edit_ankim($idankim){
                $where = array('idankim' => $idankim);
                $data4['ankim'] = $this->M_data->ankim_edit($where,'ankim')->result();
                $this->load->view('E_ankim',$data4);
            }
            function update_ankim(){
                $idankim = $this->input->post('idankim');
                $namaankim = $this->input->post('namaankim');
                $kelasankim = $this->input->post('kelasankim');
                $jurusanankim = $this->input->post('jurusanankim');
                $nikankim = $this->input->post('nikankim');
                $alamatankim = $this->input->post('alamatankim');

                $where = array (
                    'idankim' => $idankim
                );
                $data4 = array(
                    'namaankim' => $namaankim,
                    'kelasankim' => $kelasankim,
                    'jurusanankim' => $jurusanankim,
                    'nikankim' => $nikankim,
                    'alamatankim' => $alamatankim
                );
                $this->session->set_flashdata('respon', 'updated');
                $this->M_data->ankim_update($where,'ankim',$data4);
                redirect('Control/ankim');
            }
            function ankim_hapus($idankim){
                $where = array (
                    'idankim' => $idankim
                );
                $this->session->set_flashdata('respon', 'deleted');
                $this->M_data->hapus_ankim($where,'ankim');
                redirect('Control/ankim');
            }
            //unntuk web awal
            function rpluser(){
                $data5['tutor'] = $this->M_data->userrpl()->result();
                $this->load->view('Userrpl',$data5);
                $this->load->helper('url');
            }
            function tkjuser(){
                $data6['tkj'] = $this->M_data->usertkj()->result();
                $this->load->view('Usertkj',$data6);
                $this->load->helper('url');
        }
        function perkesuser(){
            $data7['perkes'] = $this->M_data->userperkes()->result();
            $this->load->view('Userperkes',$data7);
            $this->load->helper('url');
    }
            function ankimuser(){
            $data8['ankim'] = $this->M_data->userankim()->result();
            $this->load->view('Userankim',$data8);
            $this->load->helper('url');
    }
    function farmasiuser(){
        $data9['farmasi'] = $this->M_data->userfarmasi()->result();
        $this->load->view('Userfarmasi',$data9);
        $this->load->helper('url'); 
    }
    //untuk Login
    public function Pagelogin(){
		if($this->session->userdata('authenticated'))
        redirect ('Control/hallogin');

	}
    public function hallogin(){
       return $this->load->view('Login'); 
    }

	public function Login(){
		$username = $this->input->post('username'); 	
		$password = md5($this->input->post('password')); 
		
		$user = $this->M_data->get($username);
		
		if(empty($user)){ 
			$this->session->set_flashdata('message', 'Username tidak ditemukan'); 
			redirect('Control/hallogin'); 
				}else{
			if($password == $user->password){ 
					$session = array(
					'authenticated'=>true, 
					'username'=>$user->username,  
					'nama'=>$user->nama 
				);

				$this->session->set_userdata($session); 
				redirect('Page/Admin'); 
			}else{
				$this->session->set_flashdata('message', 'Password salah'); 
				redirect('Control/hallogin'); 
			}
		}
	}
    public function logout(){
		$this->session->sess_destroy(); 
		$this->load->view('awal');
	}
    //gambar
    public function tampil_gallery(){
        $data10['gambar'] = $this->M_data->tampil_gambar()->result();
        $this->load->view('V_gallery',$data10);
        $this->load->helper('url');
    }
    public function gambar(){
        $data11['gambar'] = $this->M_data->gambaran()->result();
        $this->load->view("images/",$data10);
        $this->load->helper('url');
    }
}